<?php
//Received help from Mayank
// create array between 0 and 6
// random between 0 and 6
//create sections for domino
// inside loop generate a number and assign it to the array
// use for loop that loops 100 times
// for i = 0 to 100
// array [i] = rand()
$dominoes = ['zero', 'one', 'two', 'three', 'four', 'five', 'six'];

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http - equiv="X-UA-Compatible" content="ie=edge">
  <title> Dominoes with PHP </title>
    <link rel="stylesheet" href="dominoes.css">
</head>

<body>
  <h1> Frah's Dominoes</h1>
  <div class="dominoes"> 
  <?php 
  for ($p = 0; $p < 100; $p++) {
    ?>
  <?php $dominorand1 = rand(0, count($dominoes) - 1);
  $dominorand2 = rand(0, count($dominoes) - 1);
  ?>
<div class="domino">
<div class="dots <?php echo $dominoes[$dominorand1]; ?>">
<?php
for ($i = 0; $i < $dominorand1; $i++) {
  echo ' <div class="dot"></div>';
} ?>
</div>
<div class="dots <?php echo $dominoes[$dominorand2]; ?>">
<?php
for ($j = 0; $j < $dominorand2; $j++) {
  echo ' <div class="dot"></div>';
} ?>
</div>
</div>
<?php 
} ?>
</div>
</body>
</html>